package dummyApiTest;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dummyApi.TestBase;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class post extends TestBase {

	@BeforeClass
	void profileSeller() throws InterruptedException {
		logger.info("****Strarted TC001_POST-lLOGIN****");
		RestAssured.baseURI = "http://dummy.restapiexample.com/api";
		httpRequest = RestAssured.given();
		Thread.sleep(5000);
	}

	@Test
	public void submitForm() {
		// RestAssured.baseURI = "https://www.example.com";
		httpRequest.urlEncodingEnabled(true).param("name", "Ramakeishna").param("salary", "25000").param("age", "24")
				.header("Accept", ContentType.JSON.getAcceptHeader()).post("/v1/create").then().statusCode(200);
	}

}
