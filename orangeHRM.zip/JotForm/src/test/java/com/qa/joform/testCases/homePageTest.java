package com.qa.joform.testCases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.jotform.base.testBase;
import com.qa.jotform.pages.homePage;
import com.qa.jotform.pages.loginPage;

public class homePageTest extends testBase {
	loginPage login;
	homePage homepage = new homePage();

	public homePageTest() {
		super();
	}

	@BeforeMethod
	public void setup() {
		initialazation();
		homepage = new homePage();
		login = new loginPage();
		login.login(prop.getProperty("username"), prop.getProperty("password"));
	}

	@Test
	public void loginTest() throws InterruptedException {
		homepage.addEmployee();
	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
