package com.qa.joform.testCases;

import java.util.ArrayList;
import java.util.Iterator;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.qa.jotform.base.testBase;
import com.qa.jotform.pages.homePage;
import com.qa.jotform.pages.leavePage;
import com.qa.jotform.pages.loginPage;

public class leavePageTest extends testBase {
	loginPage LoginPage;
	homePage homepage = new homePage();
	leavePage leave;

	public leavePageTest() {
		super();
	}

	@BeforeMethod
	public void setup() {
		initialazation();
		LoginPage = new loginPage();
		LoginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		leave = new leavePage();
	}

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = com.qa.jotform.utility.TestRamUtill.getDataFromExcel();
		return testData.iterator();
	}

	@Test(dataProvider = "getTestData")
	public void registrationTest(String Name, String LeaveType, String LeaveFromDate, String LeaveToDate,
			String textComment) throws InterruptedException {

		driver.findElement(By.cssSelector("#menu_leave_viewLeaveModule")).click();

		driver.findElement(By.cssSelector("#menu_leave_assignLeave")).click();

		driver.findElement(By.cssSelector("input#assignleave_txtEmployee_empName")).clear();
		driver.findElement(By.cssSelector("input#assignleave_txtEmployee_empName")).sendKeys(Name);

		Select text = new Select(driver.findElement(By.cssSelector("select#assignleave_txtLeaveType")));

		text.selectByVisibleText(LeaveType);

		// Actions action=new Actions(driver);
		// action.click().build().perform();

		driver.findElement(By.cssSelector("input#assignleave_txtFromDate")).clear();
		driver.findElement(By.cssSelector("input#assignleave_txtFromDate")).sendKeys(LeaveFromDate);
		driver.findElement(By.cssSelector("input#assignleave_txtFromDate")).click();

		// Actions action=new Actions(driver);
		// WebElement
		// date=(driver.findElement(By.cssSelector("input#assignleave_txtFromDate")));
		// action.click(date).sendKeys(LeaveFromDate).build().perform();

		Thread.sleep(5000);
		driver.findElement(By.cssSelector("input#assignleave_txtToDate")).clear();
		driver.findElement(By.cssSelector("input#assignleave_txtToDate")).sendKeys(LeaveToDate);
		driver.findElement(By.cssSelector("input#assignleave_txtToDate")).click();
		// action.contextClick(date).build().perform();

		// Thread.sleep(5000);

		// Select day = new
		// Select(driver.findElement(By.cssSelector("select#assignleave_duration_duration")));
		// day.selectByVisibleText(duration);

		// Thread.sleep(5000);
		driver.findElement(By.cssSelector("#assignleave_txtComment")).clear();
		driver.findElement(By.cssSelector("#assignleave_txtComment")).sendKeys(textComment);

		// driver.findElement(By.cssSelector("#assignBtn")).click();

	}

}
