package com.qa.jotform.utility;

import java.util.ArrayList;

public class TestRamUtill {
	static Xls_Reader reader;
	public static String currrntDirectory;
	public static ArrayList<Object[]> getDataFromExcel() {
		
		currrntDirectory = System.getProperty("user.dir");
		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {
			reader = new Xls_Reader(currrntDirectory +"\\ExcellFile\\orange (15).xlsx");
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (int rowNum = 2; rowNum <= reader.getRowCount("assignLeave"); rowNum++) {

			System.out.println("=====");

			String Name = reader.getCellData("assignLeave", "Name", rowNum);
			String LeaveType = reader.getCellData("assignLeave", "LeaveType", rowNum);
			String LeaveFromDate = reader.getCellData("assignLeave", "LeaveFromDate", rowNum);
			String LeaveToDate = reader.getCellData("assignLeave", "LeaveToDate", rowNum);
			
			//String duration = reader.getCellData("assignLeave", "duration", rowNum);
			String textComment = reader.getCellData("assignLeave", "textComment", rowNum);
			

			Object ob[] = { Name, LeaveType, LeaveFromDate, LeaveToDate, textComment};
			myData.add(ob);
		}
		return myData;
	}
}
