package com.qa.jotform.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.jotform.base.testBase;

public class personalDetailsPage extends testBase {
	@FindBy(css = "input#btnSave")
	WebElement clickOnEditButton;
	
	@FindBy(css = "#personal_txtOtherID")
	WebElement enterPersonal_TxtOtherID;

	@FindBy(css = "#personal_txtLicenNo")
	WebElement personal_txtLicenNo;

	@FindBy(css = "#personal_txtLicExpDate")
	WebElement personal_txtLicExpDate;

	@FindBy(css = ".ui-state-default.ui-state-hover")
	WebElement datepicker;

	@FindBy(css = "#personal_optGender_1")
	WebElement personal_optGender_1;

	@FindBy(css = "#personal_cmbMarital")
	WebElement clickOnMaritalStatus;

	@FindBy(css = "#personal_cmbMarital > option:nth-child(2)")
	WebElement selectStatus;

	@FindBy(css = "#personal_cmbNation")
	WebElement clickOnNation;

	@FindBy(css = "#personal_cmbNation > option:nth-child(83)")
	WebElement selectNation;

	@FindBy(css = "#personal_txtEmpNickName")
	WebElement nickName;

	@FindBy(css = "#personal_txtMilitarySer")
	WebElement militaryService;

	@FindBy(css = "#personal_chkSmokeFlag")
	WebElement personal_chkSmokeFlag;

	@FindBy(css = "input#btnSave")
	WebElement save;

	public personalDetailsPage() {
		PageFactory.initElements(driver, this);

	}

	public void fillThePersonalDetails() {

		clickOnEditButton.click();
		enterPersonal_TxtOtherID.sendKeys("23231");
		personal_txtLicenNo.sendKeys("12344");
		personal_txtLicExpDate.click();
		datepicker.click();
		personal_optGender_1.click();
		clickOnMaritalStatus.click();
		selectStatus.click();
		clickOnNation.click();
		selectNation.click();
		nickName.sendKeys("rk");
		militaryService.sendKeys("no");
		personal_chkSmokeFlag.click();
		save.click();

	}

}
