package com.qa.jotform.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.jotform.base.testBase;

public class loginPage extends testBase {
	@FindBy(xpath = "//*[@id='txtUsername']")
	WebElement username;

	@FindBy(xpath = "//*[@id='txtPassword']")
	WebElement password;

	@FindBy(xpath = "//*[@id='btnLogin']")
	WebElement lgnBtn;

	public loginPage() {
		PageFactory.initElements(driver, this);

	}

	public String validateLoginPage() {
		return driver.getTitle();

	}

	public void login(String un, String pwd) {
		username.sendKeys(un);
		password.sendKeys(pwd);
		lgnBtn.click();

	}

}
