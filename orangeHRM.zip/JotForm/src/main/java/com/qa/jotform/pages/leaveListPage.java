package com.qa.jotform.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.jotform.base.testBase;

public class leaveListPage extends testBase {

	@FindBy(xpath = "//a[@href='/index.php/leave/viewLeaveModule']")
	WebElement clickOnLeavePage;

	@FindBy(css = "#menu_leave_viewLeaveList")
	WebElement clickOnLeaveListButton;

	@FindBy(css = "#frmFilterLeave > fieldset > ol > li:nth-child(1) > img")
	WebElement clickOnfromDate;

	@FindBy(css = "tr:nth-child(4) > td:nth-child(4) > a")
	WebElement selectOnFromDate;

	@FindBy(css = "input#calToDate")
	WebElement clickOnToDate;

	@FindBy(css = "tr:nth-child(5) > td:nth-child(3) > a")
	WebElement selectOnToDate;

	@FindBy(css = "input#leaveList_chkSearchFilter_1")
	WebElement showTheLeaveWithStatus;

	@FindBy(css = "input#leaveList_txtEmployee_empName")
	WebElement employeeName;

	@FindBy(css = "#leaveList_cmbSubunit")
	WebElement subUnit;

	@FindBy(css = "#leaveList_cmbSubunit > option:nth-child(0)")
	WebElement selectTheOption;

	@FindBy(css = "#leaveList_cmbWithTerminated")
	WebElement clickOnPostEmployes;

	@FindBy(css = "#btnSearch")
	WebElement clickOnSearchButton;

	public leaveListPage() {
		PageFactory.initElements(driver, this);

	}

	public void leavePage() {
		clickOnLeavePage.click();
		clickOnLeaveListButton.click();
		clickOnfromDate.click();
		selectOnFromDate.click();
		// clickOnfromDate.click();
		clickOnToDate.click();
		selectOnToDate.click();
		// selectOnToDate.click();
		// selectOnToDate.click();
		//showTheLeaveWithStatus.click();
		employeeName.sendKeys("Sara Tencrady");
		//subUnit.click();
		//selectTheOption.click();
		clickOnPostEmployes.click();
		clickOnSearchButton.click();
	}

}
