package com.qa.jotform.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.jotform.base.testBase;

public class homePage extends testBase {
	@FindBy(css = "#menu_pim_viewPimModule")
	WebElement PIM;

	@FindBy(xpath = "//a[@href='/index.php/pim/addEmployee']")
	WebElement ClickOnAddEmployee;

	@FindBy(css = "#firstName")
	WebElement enterFirstName;

	@FindBy(css = "#middleName")
	WebElement enterMiddleName;

	@FindBy(css = "#lastName")
	WebElement enterLastName;

	@FindBy(css = "#photofile")
	WebElement uploadFile;

	@FindBy(css = "#chkLogin")
	WebElement clickOnCreateLoginButton;

	@FindBy(css = "#user_name")
	WebElement enterUserName;

	@FindBy(css = "#user_password")
	WebElement enterUser_password;

	@FindBy(css = "#re_password")
	WebElement enterRe_password;

	@FindBy(css = "#status")
	WebElement checkTheStatus;

	@FindBy(css = "#btnSave")
	WebElement SaveButton;

	@FindBy(css = "input#btnSave")
	WebElement clickOnEditButton;

	@FindBy(css = "#personal_txtOtherID")
	WebElement enterPersonal_TxtOtherID;

	@FindBy(css = "#personal_txtLicenNo")
	WebElement personal_txtLicenNo;

	@FindBy(css = "#personal_txtLicExpDate")
	WebElement personal_txtLicExpDate;

	@FindBy(css = ".ui-state-default.ui-state-hover")
	WebElement datepicker;

	@FindBy(css = "#personal_txtNICNo")
	WebElement ssnNumber;

	@FindBy(css = "#personal_txtSINNo")
	WebElement sinNumber;

	@FindBy(css = "input#personal_DOB")
	WebElement dob;

	@FindBy(css = "#personal_optGender_1")
	WebElement personal_optGender_1;

	@FindBy(css = "#personal_cmbMarital")
	WebElement clickOnMaritalStatus;

	@FindBy(css = "#personal_cmbMarital > option:nth-child(2)")
	WebElement selectStatus;

	@FindBy(css = "#personal_cmbNation")
	WebElement clickOnNation;

	@FindBy(css = "#personal_cmbNation > option:nth-child(83)")
	WebElement selectNation;

	@FindBy(css = "#personal_txtEmpNickName")
	WebElement nickName;

	@FindBy(css = "#personal_txtMilitarySer")
	WebElement militaryService;

	@FindBy(css = "#personal_chkSmokeFlag")
	WebElement personal_chkSmokeFlag;

	@FindBy(css = "input#btnSave")
	WebElement save;

	@FindBy(css = "input#btnEditCustom")
	WebElement customEdit;

	@FindBy(css = "#frmEmpCustomFields > ol > li > select")
	WebElement clickOnBloodType;

	@FindBy(css = "#frmEmpCustomFields > ol > li > select > option:nth-child(6)")
	WebElement selectBloodType;
	
	@FindBy(css = "input#btnEditCustom")
	WebElement clickOnSaveButton;
	
	//input#btnEditCustom

	public homePage() {
		PageFactory.initElements(driver, this);

	}

	public String validateHomePage() {
		return driver.getTitle();

	}

	public void addEmployee() throws InterruptedException {
		PIM.click();
		ClickOnAddEmployee.click();
		enterFirstName.sendKeys("rama");
		enterMiddleName.sendKeys("kiran");
		enterLastName.sendKeys("krishna");
		uploadFile.sendKeys("C:\\Users\\ramak\\Desktop\\New folder\\GradeBEA\\JotForm\\photos\\photo.jpg");
		clickOnCreateLoginButton.click();
		enterUserName.sendKeys("Ram177");
		enterUser_password.sendKeys("Rk48237@");
		enterRe_password.sendKeys("Rk48237@");
		SaveButton.click();

		Thread.sleep(2000);
		// Actions action=new Actions(driver);
		// action.doubleClick(clickOnEditButton).build().perform();
		// action.moveToElement(clickOnEditButton).build().perform();

		clickOnEditButton.click();

		enterPersonal_TxtOtherID.sendKeys("23231");
		personal_txtLicenNo.sendKeys("12344");

		ssnNumber.sendKeys("123445");

		sinNumber.sendKeys("123456");

		dob.clear();
		dob.sendKeys("1990-10-23");

		personal_txtLicExpDate.click();
		datepicker.click();
		personal_optGender_1.click();
		clickOnMaritalStatus.click();
		selectStatus.click();
		clickOnNation.click();
		selectNation.click();
		nickName.sendKeys("rk");
		militaryService.sendKeys("no");
		personal_chkSmokeFlag.click();
		save.click();

		customEdit.click();
		clickOnBloodType.click();
		selectBloodType.click();
		clickOnSaveButton.click();

	}

}
