package com.qa.jotform.pages;

import java.util.ArrayList;
import java.util.Iterator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.jotform.base.testBase;

public class leavePage extends testBase {

	loginPage LoginPage;
	leavePage leave;

	@FindBy(css = "#menu_leave_viewLeaveModule")
	WebElement clickOnLeavePage;

	
	@FindBy(css="#menu_leave_assignLeave")
	WebElement clickOnAssignLeave;

	
	
	@FindBy(xpath = "input#assignleave_txtEmployee_empName")
	WebElement nameOfTheEmployee;

	@FindBy(css = "select#assignleave_txtLeaveType")
	WebElement SelectLeaveType;

	@FindBy(css = "input#assignleave_txtFromDate")
	WebElement clickOnLeaveFromDate;

	@FindBy(css = "tr:nth-child(5) > td:nth-child(2) > a")
	WebElement selectLeaveFromDate;

	@FindBy(css = "input#assignleave_txtToDate")
	WebElement clickLeaveToDate;

	@FindBy(css = "tr:nth-child(5) > td:nth-child(2) > a")
	WebElement selectLeaveToDate;

	@FindBy(css = "#assignleave_txtComment")
	WebElement enterTextComment;

	@FindBy(css = "#assignBtn")
	WebElement clickassignButton;

	public leavePage() {
		PageFactory.initElements(driver, this);

	}

	@BeforeMethod
	public void setup() {
		initialazation();
		LoginPage = new loginPage();
		LoginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		leave = new leavePage();
	}

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = com.qa.jotform.utility.TestRamUtill.getDataFromExcel();
		return testData.iterator();
	}

	@Test(dataProvider = "getTestData")
	public void registrationTest(String Name, String LeaveType, String LeaveFromDate, String LeaveToDate,
			String textComment) {

		//driver.findElement(By.xpath("//a[@href='/index.php/leave/viewLeaveModule']")).click();
		clickOnLeavePage.click();
		clickOnAssignLeave.click();
		//nameOfTheEmployee.clear();
		nameOfTheEmployee.sendKeys(Name);
		
		SelectLeaveType.clear();

		//nameOfTheEmployee

		SelectLeaveType.sendKeys(LeaveType);
		clickOnLeaveFromDate.clear();
		clickOnLeaveFromDate.sendKeys(LeaveFromDate);
		// selectLeaveFromDate.click();
		clickLeaveToDate.clear();
		clickLeaveToDate.sendKeys(LeaveToDate);
		// selectLeaveToDate.click();

		//selectLeaveToDate.sendKeys(LeaveToDate);
		enterTextComment.clear();
		enterTextComment.sendKeys(textComment);

		clickassignButton.click();
	}

	
}